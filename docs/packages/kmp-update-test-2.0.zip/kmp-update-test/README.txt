KMP Update Test 1.0

Port de diagnostico mantido pelo projeto KMP para validar atualizacoes,
rollback e preservacao de saves em hardware real.
